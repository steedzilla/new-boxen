# GnuPG Puppet Module for Boxen

Install [GnuPG](http://www.gnupg.org), the GNU project's complete and free implementation of the OpenPGP standard as defined by [RFC4880](http://www.ietf.org/rfc/rfc4880.txt).

## Usage

```puppet
include gpg
```

## Required Puppet Modules

* boxen
* homebrew

